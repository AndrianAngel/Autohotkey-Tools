;you should first Run this, then Read this
;Ctrl + F: jump to #useful stuff

;#SETUP START
#NoEnv ; Recommended for performance and compatibility with future AutoHotkey releases.
#SingleInstance force
ListLines Off
SetBatchLines -1
SendMode Input ; Recommended for new scripts due to its superior speed and reliability.
SetWorkingDir %A_ScriptDir% ; Ensures a consistent starting directory.
#KeyHistory 0
#WinActivateForce

Process, Priority,, H

SetWinDelay -1
SetControlDelay -1

;START of gui stuff
Gui,Font, s12, Segoe UI
explanation=
(
CUSTOM VIRTUAL DESKTOP HOTKEYS:

LEFT CTRL + Numpad [1-9]: Go to desktop by number
    Example: LCtrl + Numpad3 = Go to Desktop 3

LEFT CTRL + WIN + Numpad [1-9]: Move active window to desktop and follow
    Example: LCtrl + Win + Numpad2 = Move window to Desktop 2 and follow

RIGHT CTRL + Numpad [1-9]: Throw window to desktop without following
    Example: RCtrl + Numpad9 = Throw window to Desktop 3 (stay on current desktop)

Alt + Numpad+: Create new desktop and go to it
Alt + Numpad-: Remove current desktop

Additional features:
Alt + F1: See which desktop you are currently in
F6: See which desktop this window is in
Alt + F2: See total number of virtual desktops

Alt + Numpad0: Pin/Unpin this window on all desktops
)
gui, add, Edit, -vscroll -E0x200 +hwndHWndExplanation_Edit, % explanation
;deselect edit text BY moving caret to start
Postmessage,0xB1,0,0,, % "ahk_id " HWndExplanation_Edit
gui, hide
;END of gui stuff

;include the library
#Include %A_LineFile%\..\VD.ahk

;#SETUP END

VD.createUntil(3) ;create until we have at least 3 VD for numpad support

return

;Switch on gui
F12::
	Gui, Show,, VD.ahk Custom HOTKEYS
return

;#useful stuff

; LEFT CTRL + NUMPAD: Go to desktop by number
LCtrl & numpad1::VD.goToDesktopNum(1)
LCtrl & numpad2::VD.goToDesktopNum(2)
LCtrl & numpad3::VD.goToDesktopNum(3)
LCtrl & numpad4::VD.goToDesktopNum(4)
LCtrl & numpad5::VD.goToDesktopNum(5)
LCtrl & numpad6::VD.goToDesktopNum(6)
LCtrl & numpad7::VD.goToDesktopNum(7)
LCtrl & numpad8::VD.goToDesktopNum(8)
LCtrl & numpad9::VD.goToDesktopNum(9)

; LEFT CTRL + WIN + NUMPAD: Move window to desktop and follow
#If GetKeyState("LCtrl", "P")
    LWin & numpad1::VD.MoveWindowToDesktopNum("A",1).follow()
    LWin & numpad2::VD.MoveWindowToDesktopNum("A",2).follow()
    LWin & numpad3::VD.MoveWindowToDesktopNum("A",3).follow()
    LWin & numpad4::VD.MoveWindowToDesktopNum("A",4).follow()
    LWin & numpad5::VD.MoveWindowToDesktopNum("A",5).follow()
    LWin & numpad6::VD.MoveWindowToDesktopNum("A",6).follow()
    LWin & numpad7::VD.MoveWindowToDesktopNum("A",7).follow()
    LWin & numpad8::VD.MoveWindowToDesktopNum("A",8).follow()
    LWin & numpad9::VD.MoveWindowToDesktopNum("A",9).follow()
#If

; RIGHT CTRL + NUMPAD: Throw window to desktop without following
RCtrl & numpad1::VD.MoveWindowToDesktopNum("A",1)
RCtrl & numpad2::VD.MoveWindowToDesktopNum("A",2)
RCtrl & numpad3::VD.MoveWindowToDesktopNum("A",3)
RCtrl & numpad4::VD.MoveWindowToDesktopNum("A",4)
RCtrl & numpad5::VD.MoveWindowToDesktopNum("A",5)
RCtrl & numpad6::VD.MoveWindowToDesktopNum("A",6)
RCtrl & numpad7::VD.MoveWindowToDesktopNum("A",7)
RCtrl & numpad8::VD.MoveWindowToDesktopNum("A",8)
RCtrl & numpad9::VD.MoveWindowToDesktopNum("A",9)

;getters and stuff (unchanged)
f6::
    msgbox % VD.getDesktopNumOfWindow("VD.ahk Custom Hotkeys")
return
!f1::
    msgbox % VD.getCurrentDesktopNum()
return
!f2::
    msgbox % VD.getCount()
return

;Create/Remove Desktop (unchanged as requested)
!NumpadAdd::VD.createDesktop(true) ;go to newly created
!NumpadSub::VD.removeDesktop(VD.getCurrentDesktopNum())

;Pin Window
!numpad0::
    VD.TogglePinWindow("A")
return

f3::Exitapp